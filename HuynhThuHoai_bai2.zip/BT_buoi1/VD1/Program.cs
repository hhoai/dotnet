﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("nhap ma so: ");
int ms = int.Parse(Console.ReadLine());
Console.WriteLine("nhap ho ten: ");
string hoten = Console.ReadLine();
Console.WriteLine("nhap luong: ");
double luong = double.Parse(Console.ReadLine());
Console.Write("ma so: {0}; ho ten: {1}, luong: {3}", ms, hoten, luong);
Console.ReadLine();
